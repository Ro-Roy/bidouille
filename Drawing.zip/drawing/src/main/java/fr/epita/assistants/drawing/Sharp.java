package fr.epita.assistants.drawing;

import fr.epita.assistants.drawing.Entity;

public abstract class Sharp extends Entity {
    int length;

    public Sharp(int length) {
        super();
        this.length = length;
    }
}