package fr.epita.assistants.drawing;

import fr.epita.assistants.drawing.Sharp;

public class Rectangle extends Sharp {
    int width;

    public Rectangle(int width,int length) {
        super(length);
        this.width = width;
    }

    private void drawWidth()
    {
        for (int i = 0; i < width; i++)
        {
            System.out.printf("#");
            if (i != width - 1 )
                System.out.printf(" ");
        }
        System.out.println();
    }

    @Override
    public void draw() {
        if (length == 1)
            System.out.println("#");

        else {
            drawWidth();
            for (int i = 0; i < length - 2; i++)
            {
                System.out.printf("#");
                for (int j = 0; j < (width - 2) * 2 + 1;j++)
                    System.out.printf(" ");
                System.out.printf("#\n");
            }
            drawWidth();
        }
    }
}