package fr.epita.assistants.drawing;

public interface IDrawable {

   void draw();
}