package fr.epita.assistants.drawing;

public abstract class Entity implements IDrawable
{
    private long id;
    private static long SEQUENCE = 0;

    public long getId()
    {
        return id;
    }

    public Entity() {
        this.id = SEQUENCE;
        SEQUENCE++;
    }

    @Override
    public void draw() {
        return;
    }
}