package fr.epita.assistants.drawing;

import fr.epita.assistants.drawing.Entity;

public class Circle extends Entity {

    int radius;

    public Circle(int radius) {
        super();
        this.radius = radius;
    }
    /*

     */
    @Override
    public void draw() {
        for (int y = -radius; y <= radius; y++)
        {
            for (int x = -radius; x <= radius; x++)
            {
                int sqdist = Math.abs(radius * radius - (x * x + y * y));

                if (sqdist < radius) {
                    System.out.printf("#");
                    if (Math.abs(y) == radius && Math.abs(x) < radius)
                        System.out.printf(" ");

                }
                else {
                    if (x != 0)
                        System.out.printf(" ");
                    else {
                        System.out.printf(" ");
                        if (Math.abs(y) != radius)
                            System.out.printf(" ");
                    }
                    System.out.printf(" ");
                }
            }
            System.out.println();
        }
    }
}//  #       #
