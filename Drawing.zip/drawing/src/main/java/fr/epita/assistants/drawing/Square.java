package fr.epita.assistants.drawing;

import fr.epita.assistants.drawing.Rectangle;

public class Square extends Rectangle {
    public Square(int width) {
        super(width,width);
    }
}