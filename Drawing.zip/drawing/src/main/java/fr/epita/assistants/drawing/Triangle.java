package fr.epita.assistants.drawing;

import fr.epita.assistants.drawing.Sharp;

public class Triangle extends Sharp {

    public Triangle(int length) {
        super(length);
    }

    private void drawLine(int row)
    {
       if (row == this.length)
       {
           for (int i = 0 ; i < length; i++) {
               System.out.printf("#");
               if (i != length - 1)
                   System.out.printf(" ");
           }
           System.out.println();
           return;
       }
       if (row == 1)
       {
           System.out.println("#");
       }
       else
       {
           System.out.printf("#");
           for (int i = 0 ; i < 1 + (row - 2) * 2; i++)
           {
               System.out.printf(" ");
           }
           System.out.println("#");
       }
    }//"# # # #"

    @Override
    public void draw() {
        for (int i = 1; i <= length; i++)
            drawLine(i);
    }
}